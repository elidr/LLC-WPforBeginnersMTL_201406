<form role="search" method="get" id="searchform" action="<?php bloginfo('url'); ?>">
	<input type="text" value="Search..." title="Search..." name="s" id="s" >
	<input type="submit" id="searchsubmit" value="Search">
</form>