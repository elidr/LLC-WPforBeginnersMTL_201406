	</div> <!--.content-->
</div> <!--/wrapper-->


<div class="footer" class="">
	<footer class="footerInner">
		<p>&copy; Your Name Here.</p>
		<p class="cred"><a href="http://ladieslearningcode.com">Ladies Learning Code</a></p>
	</footer>
	<?php wp_footer(); ?>
</div>


</body>
</html>